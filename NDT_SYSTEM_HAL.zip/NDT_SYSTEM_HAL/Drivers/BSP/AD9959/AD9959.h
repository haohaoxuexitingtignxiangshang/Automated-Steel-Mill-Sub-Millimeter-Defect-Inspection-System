#ifndef _AD9959_H_
#define _AD9959_H_

#include "./BSP/include/include.h"

//AD9959�Ĵ�����ַ����
#define CSR_ADD   0x00   //CSR ͨ��ѡ��Ĵ���
#define FR1_ADD   0x01   //FR1 ���ܼĴ���1
#define FR2_ADD   0x02   //FR2 ���ܼĴ���2
#define CFR_ADD   0x03   //CFR ͨ�����ܼĴ���
#define CFTW0_ADD 0x04   //CTW0 ͨ��Ƶ��ת���ּĴ���
#define CPOW0_ADD 0x05   //CPW0 ͨ����λת���ּĴ���
#define ACR_ADD   0x06   //ACR ���ȿ��ƼĴ���
#define LSRR_ADD  0x07   //LSR ͨ������ɨ��Ĵ���
#define RDW_ADD   0x08   //RDW ͨ����������ɨ��Ĵ���
#define FDW_ADD   0x09   //FDW ͨ����������ɨ��Ĵ���

//AD9959�ܽź궨��



#define CS(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET); \
                  }while(0) 
#define SCLK(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET); \
                  }while(0) 
#define UPDATE(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET); \
                  }while(0) 
#define PS0(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET); \
                  }while(0) 
#define PS1(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_RESET); \
                  }while(0) 
#define PS2(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_RESET); \
                  }while(0) 
#define PS3(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET); \
                  }while(0) 
#define SDIO0(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET); \
                  }while(0) 
#define SDIO1(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET); \
                  }while(0) 
#define SDIO2(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET); \
                  }while(0) 
#define SDIO3(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET); \
                  }while(0) 
#define AD9959_PWR(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET); \
                  }while(0) 
#define Reset(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); \
                  }while(0) 

			  
#define ACC_FRE_FACTOR	8.589934592

//CSR[7:4]ͨ��ѡ������λ
#define CH0 0x10
#define CH1 0x20
#define CH2 0x40
#define CH3 0x80

void delay1 (uint32_t length);
void IntReset(void);	       //AD9959��λ
void IO_Update(void);          //AD9959��������
void Intserve(void);		   //IO�ڳ�ʼ��
void Init_AD9959(void);
void AD9959_WriteData(uint8_t RegisterAddress, uint8_t NumberofRegisters, uint8_t *RegisterData);//��AD9959д����
void Write_CFTW0(uint32_t fre);										//дCFTW0ͨ��Ƶ��ת���ּĴ���
void Write_ACR(uint16_t Ampli);										//дACRͨ������ת���ּĴ���
void Write_CPOW0(uint16_t Phase);									//дCPOW0ͨ����λת���ּĴ���
void AD9959_Set_Fre(uint8_t Channel,uint32_t Freq);                 //дƵ��
void AD9959_Set_Amp(uint8_t Channel, uint16_t Ampli);               //д����
void AD9959_Set_Phase(uint8_t Channel,uint16_t Phase);              //д��λ

#endif


