#ifndef _Channel_H_
#define _Channel_H_

#include "./BSP/include/include.h"


#define E1_ENABLE 	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET)
#define E1_DISABLE 	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET)

#define E2_ENABLE 	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_11, GPIO_PIN_RESET)
#define E2_DISABLE 	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_11, GPIO_PIN_SET)


#define S10(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOD, GPIO_PIN_6, GPIO_PIN_RESET); \
                  }while(0) 
#define S11(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, GPIO_PIN_RESET); \
                  }while(0) 
#define S12(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_RESET); \
                  }while(0) 
#define S13(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_RESET); \
                  }while(0) 
#define S20(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_6, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_6, GPIO_PIN_RESET); \
                  }while(0) 
#define S21(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_7, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_7, GPIO_PIN_RESET); \
                  }while(0) 
#define S22(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_8, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_8, GPIO_PIN_RESET); \
                  }while(0) 
#define S23(x)   do{ x ? \
                      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_9, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(GPIOG, GPIO_PIN_9, GPIO_PIN_RESET); \
                  }while(0) 


void CD74HC4067_Init(void);
void Select_Channel(void);
void Mode_selection(char mode); 

extern int16_t select_Channel;

#endif

