#ifndef _AD7606_H_
#define _AD7606_H_

#include "./BSP/include/include.h"

#define CH_NUM			8				// �ɼ�8ͨ�� 

// ����GPIO�˿� 
#define RCC_SCK 	RCC_AHB1Periph_GPIOB
#define PORT_SCK	GPIOB
#define PIN_SCK		GPIO_PIN_3

#define RCC_MOSI 	RCC_AHB1Periph_GPIOB
#define PORT_MOSI	GPIOB
#define PIN_MOSI	GPIO_PIN_5

#define RCC_MISO 	RCC_AHB1Periph_GPIOB
#define PORT_MISO	GPIOB
#define PIN_MISO	GPIO_PIN_4

#define SCK_0()		HAL_GPIO_WritePin(PORT_SCK, PIN_SCK, GPIO_PIN_RESET)
#define SCK_1()		HAL_GPIO_WritePin(PORT_SCK, PIN_SCK, GPIO_PIN_SET)

#define MOSI_0()	HAL_GPIO_WritePin(PORT_MOSI, PIN_MOSI, GPIO_PIN_RESET)
#define MOSI_1()	HAL_GPIO_WritePin(PORT_MOSI, PIN_MOSI, GPIO_PIN_SET)

#define MISO_IS_HIGH()	(HAL_GPIO_ReadPin(PORT_MISO, PIN_MISO) == 1)
	
	
	
// Ƭѡ 

#define AD_CS_0()					    	HAL_GPIO_WritePin(PORT_CS, PIN_CS, GPIO_PIN_RESET)
#define AD_CS_1()						    HAL_GPIO_WritePin(PORT_CS, PIN_CS, GPIO_PIN_SET)

// �������� 
#define AD_RANGE_5V()					  HAL_GPIO_WritePin(PORT_RANGE, PIN_RANGE, GPIO_PIN_RESET)
#define AD_RANGE_10V()					  HAL_GPIO_WritePin(PORT_RANGE, PIN_RANGE, GPIO_PIN_SET)

// ��λ���� 
#define AD_RESET_LOW()					HAL_GPIO_WritePin(PORT_RESET, PIN_RESET, GPIO_PIN_RESET)
#define AD_RESET_HIGH()					HAL_GPIO_WritePin(PORT_RESET, PIN_RESET, GPIO_PIN_SET)

// ��ʼ�ź�
#define	AD_CONVST_LOW()					HAL_GPIO_WritePin(PORT_CONVST, PIN_CONVST, GPIO_PIN_RESET)
#define	AD_CONVST_HIGH()				HAL_GPIO_WritePin(PORT_CONVST, PIN_CONVST, GPIO_PIN_SET)

	
	 

// CSNƬѡ 
#define RCC_CS 		RCC_AHB1Periph_GPIOF
#define PORT_CS		GPIOF
#define PIN_CS		GPIO_PIN_7

//RESET 
#define RCC_RESET 	RCC_AHB1Periph_GPIOH
#define PORT_RESET	GPIOB
#define PIN_RESET	  GPIO_PIN_13
//RANGE 		
#define RCC_RANGE 	RCC_AHB1Periph_GPIOA
#define PORT_RANGE 	GPIOA
#define PIN_RANGE 	GPIO_PIN_4

#define RESET_0()	HAL_GPIO_WritePin(PORT_RESET, PIN_RESET, GPIO_PIN_RESET)
#define RESET_1()	HAL_GPIO_WritePin(PORT_RESET, PIN_RESET, GPIO_PIN_SET)

// CONVST		
#define RCC_CONVST 	RCC_AHB1Periph_GPIOH
#define PORT_CONVST	GPIOB
#define PIN_CONVST 	GPIO_PIN_12

// BUSY 
#define RCC_BUSY 	  RCC_AHB1Periph_GPIOH
#define PORT_BUSY 	GPIOF
#define PIN_BUSY  	GPIO_PIN_6
 
#define BUSY_IS_LOW()				(HAL_GPIO_ReadPin(PORT_BUSY, PIN_BUSY) == 0)

//�������˿�����
#define AD_OS0_PIN                     GPIO_PIN_13
#define AD_OS0_GPIO_PORT               GPIOG		
#define AD_OS0_GPIO_CLK                RCC_AHB1Periph_GPIOG

#define AD_OS1_PIN                     GPIO_PIN_14
#define AD_OS1_GPIO_PORT               GPIOG		
#define AD_OS1_GPIO_CLK                RCC_AHB1Periph_GPIOG

#define AD_OS2_PIN                     GPIO_PIN_15
#define AD_OS2_GPIO_PORT               GPIOG		
#define AD_OS2_GPIO_CLK                RCC_AHB1Periph_GPIOG

#define AD_OS0_0()							HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_RESET)
#define AD_OS0_1()							HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_SET)

#define AD_OS1_0()							HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_RESET)
#define AD_OS1_1()							HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_SET)

#define AD_OS2_0()							HAL_GPIO_WritePin(GPIOG, GPIO_PIN_15, GPIO_PIN_RESET)
#define AD_OS2_1()							HAL_GPIO_WritePin(GPIOG, GPIO_PIN_15, GPIO_PIN_SET)


void InitAD7606(void);
void AD7606_Scan(void);
void AD7606_Mak(void);
extern int16_t AD7606_ReadAdc(uint8_t _ch);

extern float s_volt[9];

#endif



