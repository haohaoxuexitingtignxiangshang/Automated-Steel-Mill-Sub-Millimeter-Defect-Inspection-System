#ifndef _include_H_
#define _include_H_


#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/BEEP/beep.h"
#include "./BSP/KEY/key.h"
#include "./BSP/AD9959/AD9959.h"
#include "./BSP/AD7606/AD7606.h"
#include "./BSP/Channel/Channel.h"
#include "./BSP/Data_Processing/Data_Processing.h"
#include "math.h"


#endif


